#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/utsname.h> // 包含對應的頭文件以使用 new_utsname()
#include <linux/sched/signal.h> // For task_struct
#include <linux/mm.h>  // 包含內存管理相關的頭文件
#include <linux/swap.h> // 包含交換空間相關的頭文件
#include <linux/sched/signal.h> // 包含進程相關的頭文件
#include <linux/fs.h>       // 包含文件操作相關的頭文件
#include <linux/mutex.h>    // 包含互斥鎖相關的頭文件
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/slab.h>

#define DEVICE_NAME "kfetch"
#define CLASS_NAME "kfetch"

#define KFETCH_RELEASE   (1 << 0)
#define KFETCH_NUM_CPUS  (1 << 1)
#define KFETCH_CPU_MODEL (1 << 2)
#define KFETCH_MEM       (1 << 3)
#define KFETCH_UPTIME    (1 << 4)
#define KFETCH_NUM_PROCS (1 << 5)

static DEFINE_MUTEX(kfetch_mutex);  // 定義一個互斥鎖

static ssize_t kfetch_read(struct file *filp, char __user *buffer, size_t length, loff_t *offset);
static ssize_t kfetch_write(struct file *filp, const char __user *buffer, size_t length, loff_t *offset);
static int kfetch_open(struct inode *inode, struct file *filp);
static int kfetch_release(struct inode *inode, struct file *filp);

extern struct mutex kfetch_mutex;  // 使用外部定義的互斥鎖

static int majorNumber;
static struct class* kfetchClass = NULL;
static struct cdev kfetchCdev;
static struct device* kfetchDevice = NULL;

extern const struct file_operations kfetch_fops; // Defined elsewhere

int kmod_op_flags = 0;

#define LOGO_LINES 7
static char *logo_info[] ={
"      .-.         ",
"     (.. |        ",
"     <>  |        ",
"    / --- \\       ",
"   ( |   | |      ",
" |\\\\_)___/\\)/\\    ",
" <__)------(__/   ",
"                  "};

const struct file_operations kfetch_fops = {
    .owner   = THIS_MODULE,
    .read    = kfetch_read,
    .write   = kfetch_write,
    .open    = kfetch_open,
    .release = kfetch_release,
};

static void get_cpu_model(char *model_name)
{
    unsigned int eax, ebx, ecx, edx;
    char cpu_model[64];
    int i;

    memset(cpu_model, 0, sizeof(cpu_model));

    // CPUID 指令，EAX = 0x80000002, 0x80000003, 0x80000004 获取处理器品牌字符串
    for (i = 0; i < 3; i++) {
        cpuid(0x80000002 + i, &eax, &ebx, &ecx, &edx);
        memcpy(cpu_model + i * 16, &eax, 4);
        memcpy(cpu_model + i * 16 + 4, &ebx, 4);
        memcpy(cpu_model + i * 16 + 8, &ecx, 4);
        memcpy(cpu_model + i * 16 + 12, &edx, 4);
    }

    strncpy(model_name, cpu_model, sizeof(cpu_model));
}

static void get_memory_info(long *pTotalMem, long *pFreeMem)
{
    struct sysinfo i;
    si_meminfo(&i);
    *pTotalMem = i.totalram * i.mem_unit / 1024 / 1024;
    *pFreeMem = i.freeram * i.mem_unit / 1024 / 1024;
}

static int get_process_count(void)
{
    struct task_struct *task;
    int count = 0;

    // 遍歷所有進程
    for_each_process(task) {
        count++;
    }

    return count;
}

static ssize_t kfetch_read(struct file *filp, char __user *buffer, size_t length, loff_t *offset)
{
    int bytes_read = 0;
    int buf_pos = 0;
    char kfetch_buf[2048];
    char cpu_model[64];

    int logo_line_cnt = 0;

    if(kmod_op_flags>0)
    {
        /* 獲取內核版本 */
        struct new_utsname *uts = utsname();
        if (!uts) {
            return -ENODEV; // 如果獲取失敗，返回錯誤
        }

        buf_pos += snprintf(kfetch_buf + buf_pos, sizeof(kfetch_buf) - buf_pos, "%s%s\n", logo_info[LOGO_LINES], uts->nodename);

        char* p_seperation_line = kmalloc(strlen(uts->nodename)+1, GFP_KERNEL);
        if(p_seperation_line!=NULL)
        {
            memset(p_seperation_line, 0, strlen(uts->nodename)+1);
            memset(p_seperation_line, '-', strlen(uts->nodename));
            
            buf_pos += snprintf(kfetch_buf + buf_pos, sizeof(kfetch_buf) - buf_pos, "%s%s\n", logo_info[logo_line_cnt], p_seperation_line);
            if(logo_line_cnt<LOGO_LINES){logo_line_cnt++;}

            kfree(p_seperation_line);
        }

        if(kmod_op_flags & KFETCH_RELEASE)
        {
            buf_pos += snprintf(kfetch_buf + buf_pos, sizeof(kfetch_buf) - buf_pos, "%sKernel: %s\n", logo_info[logo_line_cnt], uts->release);
            if(logo_line_cnt<LOGO_LINES){logo_line_cnt++;}
        }

        if(kmod_op_flags & KFETCH_CPU_MODEL)
        {
            get_cpu_model(cpu_model);
            buf_pos += snprintf(kfetch_buf + buf_pos, sizeof(kfetch_buf) - buf_pos, "%sCPU: %s\n", logo_info[logo_line_cnt], cpu_model);
            if(logo_line_cnt<LOGO_LINES){logo_line_cnt++;}
        }

        if(kmod_op_flags & KFETCH_NUM_CPUS)
        {
            buf_pos += snprintf(kfetch_buf + buf_pos, sizeof(kfetch_buf) - buf_pos, "%sCPUS: %d/%d\n", logo_info[logo_line_cnt], num_online_cpus(), num_possible_cpus());
            if(logo_line_cnt<LOGO_LINES){logo_line_cnt++;}
        }
        
        if(kmod_op_flags & KFETCH_MEM)
        {
            long totalMem, freeMem;
            get_memory_info(&totalMem, &freeMem);
            buf_pos += snprintf(kfetch_buf + buf_pos, sizeof(kfetch_buf) - buf_pos, "%sMem: %d MB / %d MB\n", logo_info[logo_line_cnt], freeMem, totalMem);
            if(logo_line_cnt<LOGO_LINES){logo_line_cnt++;}
        }
        
        if(kmod_op_flags & KFETCH_NUM_PROCS)
        {
            int process_count = get_process_count();
            buf_pos += snprintf(kfetch_buf + buf_pos, sizeof(kfetch_buf) - buf_pos, "%sProcs: %d\n", logo_info[logo_line_cnt], process_count);
            if(logo_line_cnt<LOGO_LINES){logo_line_cnt++;}
        }

        if(kmod_op_flags & KFETCH_UPTIME)
        {
            /* 獲取系統運行時間 */
            long uptime = jiffies_to_msecs(get_jiffies_64()) / 1000 / 60;
            buf_pos += snprintf(kfetch_buf + buf_pos, sizeof(kfetch_buf) - buf_pos, "%sUptime: %ld mins\n", logo_info[logo_line_cnt], uptime);
            if(logo_line_cnt<LOGO_LINES){logo_line_cnt++;}
        }

        while(logo_line_cnt<LOGO_LINES)
        {
            buf_pos += snprintf(kfetch_buf + buf_pos, sizeof(kfetch_buf) - buf_pos, "%s\n", logo_info[logo_line_cnt]);
            logo_line_cnt++;
        }

        /* 將信息複製到用戶空間 */
        if (copy_to_user(buffer, kfetch_buf, buf_pos)) {
            pr_alert("Failed to copy data to user");
            return -EFAULT;
        }
    }

    bytes_read = buf_pos;

    return bytes_read;
}

static ssize_t kfetch_write(struct file *filp, const char __user *buffer, size_t length, loff_t *offset)
{
    int mask_info;

    if (copy_from_user(&mask_info, buffer, length)) {
        pr_alert("Failed to copy data from user");
        return 0;
    }

    kmod_op_flags = mask_info;

    return 0;
}

static int kfetch_open(struct inode *inode, struct file *filp)
{
    if (!mutex_trylock(&kfetch_mutex)) {
        // 如果無法立即獲得鎖，則返回忙狀態
        return -EBUSY;
    }

    printk(KERN_INFO "kfetch device opened\n");

    // 這裡可以放置打開設備時需要執行的其他邏輯
    kmod_op_flags = 0;

    return 0;  // 成功打開設備
}

static int kfetch_release(struct inode *inode, struct file *filp)
{
    // 釋放在 kfetch_open 中獲取的鎖
    mutex_unlock(&kfetch_mutex);

    printk(KERN_INFO "kfetch device released\n");

    // 這裡可以放置釋放設備時需要執行的其他邏輯
    kmod_op_flags = 0;

    return 0;  // 成功釋放設備
}

static int __init kfetch_mod_module_init(void) {
    printk(KERN_INFO "kfetch: Initializing the kfetch module\n");

    // Dynamically allocate a major number for the device
    majorNumber = register_chrdev(0, DEVICE_NAME, &kfetch_fops);
    if (majorNumber < 0) {
        printk(KERN_ALERT "kfetch failed to register a major number\n");
        return majorNumber;
    }

    // Register the device class
    kfetchClass = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(kfetchClass)) {
        unregister_chrdev(majorNumber, DEVICE_NAME);
        printk(KERN_ALERT "Failed to register device class\n");
        return PTR_ERR(kfetchClass);
    }

    // Register the device driver
    kfetchDevice = device_create(kfetchClass, NULL, MKDEV(majorNumber, 0), NULL, DEVICE_NAME);
    if (IS_ERR(kfetchDevice)) {
        class_destroy(kfetchClass);
        unregister_chrdev(majorNumber, DEVICE_NAME);
        printk(KERN_ALERT "Failed to create the device\n");
        return PTR_ERR(kfetchDevice);
    }

    // Initialize the cdev structure and add it to the kernel
    cdev_init(&kfetchCdev, &kfetch_fops);
    kfetchCdev.owner = THIS_MODULE;
    cdev_add(&kfetchCdev, MKDEV(majorNumber, 0), 1);

    printk(KERN_INFO "kfetch: device class created correctly\n");
    
    kmod_op_flags = 0;

    return 0;
}

static void __exit kfetch_mod_module_exit(void) {
    cdev_del(&kfetchCdev);
    device_destroy(kfetchClass, MKDEV(majorNumber, 0));
    class_unregister(kfetchClass);
    class_destroy(kfetchClass);
    unregister_chrdev(majorNumber, DEVICE_NAME);
    
    kmod_op_flags = 0;

    printk(KERN_INFO "kfetch: Goodbye from the kfetch module!\n");
}

module_init(kfetch_mod_module_init);
module_exit(kfetch_mod_module_exit);

MODULE_LICENSE("GPL");  // Add the license here
MODULE_AUTHOR("W-Link");
MODULE_DESCRIPTION("W-Link kfetch_mod Linux Hardware Monitor");
MODULE_VERSION("0.1");
