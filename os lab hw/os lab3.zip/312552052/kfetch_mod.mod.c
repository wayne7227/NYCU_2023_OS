#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif


static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x92997ed8, "_printk" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x3050f27c, "__register_chrdev" },
	{ 0x22fd2b2f, "__class_create" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0x66679e00, "device_create" },
	{ 0xdc1950ce, "class_destroy" },
	{ 0x7b22cce6, "cdev_init" },
	{ 0x43d8172a, "cdev_add" },
	{ 0x30a339e9, "cdev_del" },
	{ 0x8007fa10, "device_destroy" },
	{ 0xaef2901a, "class_unregister" },
	{ 0xbb9ed3bf, "mutex_trylock" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x7682ba4e, "__copy_overflow" },
	{ 0x4b4834f0, "current_task" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xa916b694, "strnlen" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x8074d5b8, "init_task" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xfb578fc5, "memset" },
	{ 0x37a0cba, "kfree" },
	{ 0x9166fada, "strncpy" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x37befc70, "jiffies_to_msecs" },
	{ 0x40c7247c, "si_meminfo" },
	{ 0x17de3d5, "nr_cpu_ids" },
	{ 0xa5f7cf37, "__cpu_possible_mask" },
	{ 0x21ea5251, "__bitmap_weight" },
	{ 0xc60d0620, "__num_online_cpus" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xbf8e4f2e, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "A447520EB1B1E971FB6DEBC");
